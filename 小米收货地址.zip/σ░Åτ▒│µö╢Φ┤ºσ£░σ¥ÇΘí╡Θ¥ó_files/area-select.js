var data;
        $.ajax({url:"data/area.json",async:false,success:function(d){data = d},dataType:"json"});
        var province = data.province;
        var city = data.city;
        var district = data.district;
        //给省下拉框赋值
        var html_province = "<option value='0'>请选择省</option>";
        $.each(province,function(index,p){
            html_province+="<option value='"+ p.id+"'>"+ p.name+"</option>";
        });
        $("#fstLvlAddr").html(html_province);
        //给省下拉框绑定事件
        $("#fstLvlAddr").change(function(){
            var p_id = $(this).val();
            var html_city = "<option value='0'>请选择市</option>";
            $.each(city,function(index,c){
                if(c.parent_id == p_id){
                    html_city+="<option value='"+ c.id+"'>"+ c.name+"</option>";
                }
            });
            $("#secdLvlAddr").html(html_city).attr("disabled",false);
            $("#city-text").html("请选择市");
            $("#district-text").html("请选择区");
        });
        //给市下拉框绑定事件
        $("#secdLvlAddr").change(function(){
            var p_id = $(this).val();
            var html_district = "<option value='0'>请选择区</option>";
            $.each(district,function(index,d){
                if(d.parent_id == p_id){
                    html_district+="<option value='"+ d.id+"'>"+ d.name+"</option>";
                }
            });
            $("#thrdLvlAddr").html(html_district).attr("disabled",false);
            $("#district-text").html("请选择区");
        });

        //设置显示下拉框的值
        $("div").delegate("select","change",function(){
            $(this).prev("div.option").text($(this).children("option:selected").text());
            return false;
        });